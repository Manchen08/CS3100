#include "param.h"
#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"
#include "fcntl.h"
#include "syscall.h"
#include "traps.h"
#include "memlayout.h"

int stdout = 1;
int fd;

int main(void)
{
int magic = getMagic();
printf(1, "current magic number is the following: %d\n",magic);

incrementMagic(3);

magic = getMagic();
printf(1, "current magic number is the following: %d\n",magic);

getCurrentProcessName();

modifyCurrentProcessName("newName");

getCurrentProcessName();

magic = getMagic();
printf(1, "current magic number is the following: %d\n",magic);

incrementMagic(3);

magic = getMagic();
printf(1, "current magic number is the following: %d\n",magic);

exit();
}
