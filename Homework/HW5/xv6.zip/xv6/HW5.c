#include "param.h"
#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"
#include "fcntl.h"
#include "syscall.h"
#include "traps.h"
#include "memlayout.h"


int main(int argc, char *argv[])
{

	if(argc == 1){
		printf(1,"Please give me positive integer\n");
		exit();
	}

	if(argc > 2){
		printf(1,"Please enter one argument\n");
		exit();
	}

	if ((atoi(argv[1])) == 0){
		printf(1,"Please enter a positive integer\n");
		exit();
	}

	printf(1,"Jon Wheeler\n");
	exit();
}
